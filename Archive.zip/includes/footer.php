    </main>
    <footer>
        <!-- Footer content -->
    </footer>
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html> 